
for (var i=0; i<=6; i++) {
if(i % 2 == 0) {
    if (i!=0){
console.log("we are on mile" +i);
console.log("Candy!!!");
        }
    }
}
//I originally thought we were looking for which miles the candy would come on, so I originally had console.log(i). I had to use the solution provided on the learn app bc nowhere did we learn about modulous before the answer was provided.
//I am very confused with modulous. I am also confused when I need brackets

//We need a loop here because something is going to happen multiple times until a condition is met(runner gets candy every 2 miles until his/her 6th mile)
//The starting point of the loop is 0 b/c the runner has not started running yet.
//The loop should stop at mile 6
//the loops knows to stop at 6 because we have put in the condition that the variable must stop when it equals 6
//The amount of miles increase by 2 each loop
//We need a variable for miles run
