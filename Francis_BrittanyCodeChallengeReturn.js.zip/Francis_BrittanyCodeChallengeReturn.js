//Code Snippet 1
//Would it say hello Dojo?
function hello() {
    console.log('hello');
}
hello();
console.log('Dojo');
//It did, but on different lines.

//Code snippet 2:
//Would it console log hello first, then another console log 'result is 15'?
function hello() {
    console.log('hello');
    return 15;
}
var result = hello();
console.log('result is', result);
//yay! Prediction correct! So it looks like it calls the function, you console log what is in the function, then look down at the bottom console log and that will be the 2nd result.

//Code snippet 3:
//numPlus(3) is what is being called to this function. The 3 is the parameter I think. 
//First it will console.log num is 3
//the return will be 3+15 so result=18
//the second console.log will output result is 18
//So on different lines the output will be: num is 3. result is 18
function numPlus(num) {
    console.log('num is', num);
    return num+15;
}
var result = numPlus(3);
console.log('result is', result);
//Correct again!!! Go Brittany!

//Code snippet 4:
//This one says it has a twist
//I think it will console.log 4 different outputs since I see 4 console logs
//First it will console.log 15 bc/ that is above the function.
//Then it will console.log in the function logAndReturn (10)
//I'm not sure which number to be following. Maybe if you call the function it will console.log(15)???
var num = 15;
console.log(num);
function logAndReturn(num){
   console.log(num);   
   return num;
}
var result = logAndReturn(10);
console.log(result);
console.log(num);
//I think I am confused on this one. I get why the first console log was 15. 
//Then I guess it turns to 10 inside the function. 
//I am thinking return and result were supposed to be the same thing but since they were different words, that did not connect for me.
//So it runs console.log (15) before the function, which outputs 15
//Then it calls the functions with the parameter 10, and the output is 10, which turns into the result/return. So the next 2 outputs are 10
//And then it runs console.log (num) which was still 15. Yikes! Hope that was correct thinking

//Code Snippet 5:
//Maybe this one will make more sense!
//first console.log will output 15
//second console log is withing the function. It takes timesTwo and uses the parameter 10. The console will log and return the number*2, which will be 20
//Then it will log that result, 20 again. Then it will log the original number 15.
//So I think 15, 20, 20, 15 will be the outputs
var num = 15;
console.log(num);
function timesTwo(num){
   console.log(num);   
   return num*2;
}
var result = timesTwo(10);
console.log(result);
console.log(num);
//Ok so the 2nd console.log resulted in 10 because that was BEFORE the return multiplied it by 2. But the other 3 outcomes were predicted correctly

//Code Snippet 6:
//Do I need to add the timesTwoAgain numbers together first? Or do I call the function twice and add the results of timesTwoAgain(3) with timesTwoAgain(5)?
//Let's try calling the function twice and adding them together to create the result and see if that is correct
//first output will be 'num is 3'. That 3 will be multiplied by 2 and equal 6. That will replace the first part of the result
//second output will be num is 5. That 5 will be multiplied by 2 and equal 10. The return will replace the second half of the result
//The 6+10 will result in 16
//The last console log will say 'result is 16'
//so the 3 outputs will say 'num is 3', 'num is 5', and 'result is 16'
//Am I correct?
function timesTwoAgain(num) {
    console.log('num is', num);
    y = num*2;
    return y;
}
var result = timesTwoAgain(3) + timesTwoAgain(5);
console.log('result is', result);
//Hooray!!!!!!!! We did it

//Code Snippet 7:
//Is this one as easy as it looks?
//I think it will output the sumNums of 2+3 so the first output would equate to 5
//Then I think the 2nd output will equate to 3+5 so 8
//So are the outputs 5, 8  ?
function sumNums(num1, num2) {  
    return num1+num2;
 }
 console.log(sumNums(2,3))
 console.log(sumNums(3,5))
 
//Yes!!*Cue fireworks*

//Codes Snippet 8:
//I think this one is very similar to the one above, but it will console log num1 each time the function is run, as well as the results
//So the output should be 2,5,3,8
function printSumNums(num1, num2) {
    console.log(num1);   
    return num1+num2;
 }
 console.log(printSumNums(2,3))
 console.log(printSumNums(3,5))
 
//Correct!

//Code Snippet 9:
//So it looks like we have to call the function twice again because there are 2 sets of parameters in the result that need to be added together
//The first time you run it with (2,3) the outputs will be 'sum is 5'and that 5 goes to the result.
//The second time you run it with (3,5) the sum will be 8 so it will say 'sum is 8'
//When you add 5+8 the result var will be 13
//So the 3rd output will say "result is 13"
function sumNums(num1, num2) {
    var sum = num1 + num2;
    console.log('sum is', sum);
    return sum;
}
var result = sumNums(2,3) + sumNums(3,5);
console.log('result is', result);
//We did it again!

//Code Snippet 10: Final Challenge*duhduhduuhhhhhhhhhh*
//Oh no there are so many brackets!!! I will make more comments to help myself keep track
//PEMDAS. Start with the sumNums at the end because they are in brackets
//I start with numNums (2,1). It will console log 'sum is 3'. 
//Call function with (2,3) "sum is 5"
//But it will go through this concept multiple times because those same sets of numbers repeat quite a lot
//sumNums (3,3)=6 sumNums(3,5)=8
function sumNums(num1, num2) {
    var sum = num1 + num2;
    console.log('sum is', sum);
    return sum;
}
var result = sumNums(2,3) + sumNums(3,sumNums(2,1)) + sumNums(sumNums(2,1),sumNums(2,3));
//5+ sumNums(3,3) + snumNums(3,5)
//5+6+8
//19
//The last console.log will say 'result is 19'. The previous console.logs will all say the sum of the 2 parameters each time I am not sure in what ondragover.
console.log('result is', result);
//So the function was just called in order of the equation and did not start in the parenthesis as far as I can tell.


