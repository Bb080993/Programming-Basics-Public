//I think the function output will be "I was born in 1980"
function myBirthYearFunc(){
    console.log("I was born in" + 1980);
}
myBirthYearFunc();
//I was wrong; there is no space between in and 1980 because it was concatenated
//Will this next one do the same thing?
function myBirthYearFunc(){
    console.log("I was born in" + 1980);
}
myBirthYearFunc();
//Yes! By using the parameter of 1980 in the call function, it was inserted into the function while the console ran it
//Predict Challenge 3: this function will use parameter num1= 10 and num2=20. It will first console log "num1 is10". Then it will console log num2 is20. Then it will console log the sum, which is 30. Let's find out if I am right!!!
function add(num1, num2){
    console.log("Summing Numbers!");
    console.log("num1 is: " + num1);
    console.log("num2 is: " + num2);
    var sum = num1 + num2;
    console.log(sum);
}
add(10, 20);
//I was close! There is a colon between num1 is: 10 and num2 is:20. However, I predicted that there would be 3 outcomes, and the 3rd outcome was exactly correct! I was very close on the 1st 2 outputs.