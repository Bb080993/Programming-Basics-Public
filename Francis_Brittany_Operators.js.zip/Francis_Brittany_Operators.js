/*function howMuchLeftOverCake (numberOfPieces,numberOfPeople){
    let slices=numberOfPieces-numberOfPeople
    return slices
     }
     howMuchLeftOverCake(12,5)
     console.log(howMuchLeftOverCake(12,5))*/
//So this is the basic function needed for first part of assignment


function howMuchLeftOverCake (numberOfPieces,numberOfPeople){
    let slices=numberOfPieces-numberOfPeople
    {  if (slices==0) {console.log("No leftovers for you!")}
      else if (slices <=2) {(console.log("You have some leftovers"))}
         else if (slices <=5) {(console.log ("You have some leftovers to share"))}
          else if (slices>5) {(console.log("Hold another party!"))}
         return slices
     }}
     howMuchLeftOverCake(12,5)
     console.log(howMuchLeftOverCake(12,5))

