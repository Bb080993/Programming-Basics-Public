// #1
var arr1 = [8, 6, 7, 5, 3, 0, 9];
// #2
var arr2 = [4, 7, 13, 13, 19, 37, -2];
// #3
var arr3 = [6, 2, 12, 14, -24, 5, 0];

//Part 1: 1. Write a for loop that will traverse through an array of numbers, and print each number.

for (let i=0; i<arr2.length; i++){
    console.log(arr2[i])}{
}

//Part 2:Write a for loop that will traverse through an array of numbers, and print the sum of the number and the index of the number in the array.
let sum=0
for (let i=0; i<arr3.length; i++){
    sum=sum+arr3[i]}{
    console.log(sum)
}

//Part 3: Write a for loop that will traverse through an array of numbers, and print only the numbers greater than 5.
for (let i=0; i<arr1.length; i++){
    if (arr1[i]>5){console.log(arr1[i])}
}

/*Part 4: Ninja Bonus: Modify your solution for #3 so that any numbers in the array that are not greater than 5 are instead
 replaced with a string of "No dice." This string should not be printed.*/
 for (let i=0; i<arr1.length; i++){
    if (arr1[i]>5){console.log(arr1[i])}
    else if (arr1[i]<=5) {"No dice"}
}

