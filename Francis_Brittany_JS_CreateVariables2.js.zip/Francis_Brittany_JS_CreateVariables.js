
// variables for our program to determine if our guest can ride our coaster
// variable for minimum age must be 10
// variable for minimum height must be 42
var minimum_age = 10;
var minimum_height = 42;
var height = 50
var age =13
if (height > 42) {console.log("Get on that ride, kiddo!")
    
} else {console.log("Sorry kiddo. Maybe next year.")
    
}