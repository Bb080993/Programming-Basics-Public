

/*function greeting(name){
    return  "Good day" + ` `+ name
}

console.log(greeting('Britt'))
console.log(greeting('Anakin'))

//The above example satisfies requirements for Level 1


function hello(name){
    if (name=='Count Dooku'){return "I'm coming for you, Dooku!"}
    else {return "Good day" + ` ` + name}

}
   
console.log(hello('Count Dooku'))
console.log(hello('Britt'))
console.log(hello('Anakin'))*/

// This works for level 1 and 3 of the assignment


function hello(name,timeOfDay){
    if (name=='Count Dooku'){return "I'm coming for you, Dooku!"}
    else {return "Good day" + ` ` + name + ` ` + "it is"+ ` ` + timeOfDay}

}
   
console.log(hello('Count Dooku'))
console.log(hello('Britt','9:00'))
console.log(hello('Anakin','10pm'))
//This example would satisfy Levels 1, 2, and 3 of the assignment. Yay!