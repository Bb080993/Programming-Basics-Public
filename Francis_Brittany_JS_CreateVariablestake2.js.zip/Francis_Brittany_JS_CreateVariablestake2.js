
// variables for our program to determine if our guest can ride our coaster
// variable for minimum age must be 10
// variable for minimum height must be 42
var minimum_age = 10;
var minimum_height = 42;
var height = 12
var age =13
if (height > 42) {console.log("Get on that ride, kiddo!")
    
} else {console.log("Sorry kiddo. Maybe next year.")
    
}


//Stretch:require height>=42 && age>=10
if (height >=42 && age>=10){
    console.log("Get on that ride, kiddo!")
} else {console.log("Sorry kiddo. Maybe next year.")
}

//Stretch 2:(>=42 inches) or the age requirement (>=10 years old)
if (height>=42 || age>=10) {console.log("Get on that ride, kiddo!")}
else{console.log("Get on that ride, kiddo!")}