
    function greeting(){
        return "Hello World";
    }
    var word = greeting();
    console.log(word);
//Well I'm not sure what I was supposed to do, but it was telling me that I needed to get rid of export, so I just deleted the top line (the export function)
//Then I did console.log(word) bc the console.log was empty, which ran the function, and returned "Hello World" as the greeting
//So this is my thought process. Anyway I will wait for the solution to appear and log that on here below so I have the correct way of doing it.



//Ok. So. I had the right idea. I needed to insert 'word' into the console.log so the console.log would run something.
// It turns out I just didn't need to delete the export function, I just wasn't supposed to copy it over from Trace
//So to fix the code, simply insert 'word' into the console.log so it has something to run
